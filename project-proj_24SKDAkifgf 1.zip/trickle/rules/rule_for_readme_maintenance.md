When updating the project

- Always check if the README.md in trickle/notes needs to be updated
- Update README.md when adding new features, pages, or significant changes
- Keep the version number synchronized
- Document new user credentials if added
- Update the structure section if new files are added