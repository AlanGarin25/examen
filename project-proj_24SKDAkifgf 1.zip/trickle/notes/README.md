# Sistema de Administración con Control de Roles

## Descripción
Sistema completo de administración con autenticación, control de roles y dashboard interactivo.

## Características
- Login con diseño dividido elegante
- 3 roles de usuario: Superusuario, Administrador y Usuario
- Dashboard con estadísticas
- Sidebar con logo y navegación
- Topbar con notificaciones
- Base de datos de usuarios integrada

## Roles y Permisos

### Superusuario
- Gestión total del sistema
- Crear y eliminar usuarios
- Modificar roles
- Acceso completo

### Administrador
- Gestión de usuarios
- Ver reportes
- Modificar contenido
- Permisos básicos

### Usuario
- Ver dashboard
- Ver y editar perfil propio

## Usuarios de Prueba

**Superusuarios:**
- super1@admin.com / super123
- super2@admin.com / super123

**Administradores:**
- admin1@admin.com / admin123
- admin2@admin.com / admin123

**Usuarios:**
- user1@admin.com / user123
- user2@admin.com / user123

## Estructura
- `index.html` - Página de login
- `dashboard.html` - Panel principal
- `utils/auth.js` - Lógica de autenticación
- `components/` - Componentes reutilizables

## Versión
2.1.0